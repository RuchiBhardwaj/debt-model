export const environment = {
  production: true,
  baseURL: 'http://65.2.13.132:8080/api/v1/'
};
