export interface ICashflow {
  id?: number;
  originationDate?: string;
  maturityDate?: string;
  valuationDate?: string;
  discountRate?: string;
  presentValueSum?: string;
  percentagePar?: string;
  schedules?: Array<ISchedule>;
  pivotData?: Array<any>;
}

export interface ISchedule {
  id?: number;
  fromDate?: string;
  toDate?: string;
  principalInflow?: string;
  principalRepayment?: string;
  totalPrincipalOutstanding?: string;
  baseRate?: string;
  baseRateSpread?: string;
  totalInterestRate?: string;
  interestOutflow?: string;
  totalCashMovement?: string;
  partialPeriod?: string;
  discountingFactor?: string;
  presentValue?: string;
}

export class ScheduleClass implements ISchedule {
  principalInflow?: string = null;
  principalRepayment?: string = null;
  totalPrincipalOutstanding?: string = null;
  baseRate?: string = null;
  baseRateSpread?: string = null;
  totalInterestRate?: string = null;
  interestOutflow?: string = null;
  totalCashMovement?: string = null;
  partialPeriod?: string = null;
  discountingFactor?: string = null;
  presentValue?: string = null;
}
