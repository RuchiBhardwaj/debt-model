import { Component, OnInit, OnDestroy } from '@angular/core';
import { cashflowConstants } from 'src/app/_shared/constants';
import { CashflowService } from '../../services';
import { ICashflow } from '../../model/cashflow.model';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from 'src/app/_shared/services';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'cashflow-cashflow',
  templateUrl: './cashflow.component.html',
  styleUrls: ['./cashflow.component.scss'],
})
export class CashflowComponent implements OnInit, OnDestroy {
  public activeTab = 1;
  public constants = cashflowConstants;
  public cashflowData: ICashflow;
  private subscription$ = new Subscription();
  public debtModelId;

  constructor(
    private cashflowService: CashflowService,
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.subscription$.add(this.route.params.subscribe((params) => {

      // Fetch DebtModel ID from route
      this.debtModelId = params?.id;

      // Set the latest id as default id
      if (this.debtModelId === null || !this.debtModelId) {
        this.router.navigate(['/home']);
      } else {
        // Get cashflow data for selected DebtModel ID
        this.subscription$.add(this.cashflowService.getCashflowHorizontalView(this.debtModelId).subscribe((resp?: ICashflow) => {
          this.cashflowData = resp;
        }))
      }
    }));
  }

  ngOnDestroy(): void {
    this.subscription$.unsubscribe();
  }

}
