import { AfterViewInit, Component, ElementRef, Input, OnInit, QueryList, ViewChildren } from '@angular/core';
import { IDataOptions, IDataSet } from '@syncfusion/ej2-angular-pivotview';
import { GridSettings } from '@syncfusion/ej2-pivotview/src/pivotview/model/gridsettings';
import { cashflowConstants } from 'src/app/_shared/constants';
import { ICashflow } from '../../model/cashflow.model';

@Component({
  selector: 'cashflow-horizontal-view',
  templateUrl: './horizontal-view.component.html',
  styleUrls: ['./horizontal-view.component.scss'],
})
export class HorizontalViewComponent implements OnInit, AfterViewInit {
  @Input() CashflowData: ICashflow;
  public cashflowData;
  public pivotData: IDataSet[];
  public dataSourceSettings: IDataOptions;
  public gridSettings;
  public constants = cashflowConstants;

  dom: HTMLElement;
  blueLineScrollElement;
  pivotScrollElement;

  checkMouseTime;
  scrollTimeInterval;

  constructor(private elementRef: ElementRef) { }

  createPivotData(data): void {
    this.pivotData = data?.pivotData;
    this.dataSourceSettings = {
      dataSource: this.pivotData,
      expandAll: true,
      enableSorting: false,
      showGrandTotals: false,
      columns: [{ name: 'toDate' }],
      values: [{ name: 'value' }],
      rows: [{ name: 'title' }],
      filters: [],
      showColumnSubTotals: false,
      formatSettings: [
        { name: 'toDate', format: 'dd/MMM/yy', type: 'date' },
        { name: 'value', format: 'N', minimumFractionDigits: 3, maximumFractionDigits: 3, useGrouping: true },
      ],
      emptyCellsTextContent: '-'
    };
    this.gridSettings = {
      gridLines: 'None',
      columnWidth: 110,
      allowResizing: false,
    } as GridSettings;
  }

  scrollElement(direction, scrollNumber): void {
    direction === 'L' ? (this.pivotScrollElement.scrollLeft -= scrollNumber) : (this.pivotScrollElement.scrollLeft += scrollNumber);
  }

  mouseup(direction?): void {

    //If mouse time has not reached 500ms, consider it as click.
    if (this.checkMouseTime) {
      clearTimeout(this.checkMouseTime);
      this.checkMouseTime = null;

      // scroll with 20px
      this.scrollElement(direction, 20);
    } else {

      // stop scroll on leaving hold
      clearInterval(this.scrollTimeInterval);
      this.scrollTimeInterval = null;
    }
  }

  mousedown(direction?): void {

    // Check if click and hold for morethan 500ms
    this.checkMouseTime = setTimeout(() => {

      //If it continue to hold, stop time mouse time check and start smooth scroll
      this.scrollTimeInterval = setInterval(() => {

        //Smooth scroll with 1px
        this.scrollElement(direction, 1);
      }, 0);
      this.checkMouseTime = null;
    }, 500);
  }

  ngAfterViewInit(): void {
    this.dom = this.elementRef.nativeElement;
    this.blueLineScrollElement = this.dom.querySelectorAll('.dot-scroll')[0];
    if (this.blueLineScrollElement) {
      this.blueLineScrollElement.addEventListener('wheel', () => {
        // stopping default scroll for blueLine scroll element
        return false;
      });
    }
    setTimeout(() => {
     this.pivotScrollElement = this.dom.querySelectorAll('.e-movablescrollbar')[0];
      if (this.pivotScrollElement) {
        this.pivotScrollElement.addEventListener('scroll', () => {

          // integrating blueLine scroll with pivot table scroll
          this.blueLineScrollElement.scrollLeft = this.pivotScrollElement.scrollLeft;
        });
      }
    }, 1);
  }

  ngOnInit(): void {
    this.cashflowData = this.CashflowData;
    this.createPivotData(this.cashflowData);
  }
}
