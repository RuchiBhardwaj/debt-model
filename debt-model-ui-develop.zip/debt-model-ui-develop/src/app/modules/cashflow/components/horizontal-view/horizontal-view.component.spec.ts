import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HorizontalViewComponent } from './horizontal-view.component';
import { SharedModule } from 'src/app/_shared/shared.module';

describe('HorizontalViewComponent', () => {
  let component: HorizontalViewComponent;
  let fixture: ComponentFixture<HorizontalViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [HorizontalViewComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HorizontalViewComponent);
    component = fixture.componentInstance;
    component.CashflowData = {};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
