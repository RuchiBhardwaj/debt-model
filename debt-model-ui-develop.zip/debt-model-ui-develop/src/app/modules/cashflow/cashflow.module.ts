import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CashflowComponent, HorizontalViewComponent } from './components';
import { CashflowRoutingModule } from './cashflow-routing.module';
import { CashflowService } from './services';

import { PivotViewModule } from '@syncfusion/ej2-angular-pivotview';
import { SharedModule } from 'src/app/_shared/shared.module';
import { ButtonModule } from "@syncfusion/ej2-angular-buttons";

@NgModule({
  declarations: [CashflowComponent, HorizontalViewComponent],
  imports: [CommonModule, CashflowRoutingModule, PivotViewModule, ButtonModule, SharedModule],
  providers: [CashflowService],
})
export class CashflowModule {}
