import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CashflowComponent } from './components';

const routes: Routes = [
  {
    path: '',
    component: CashflowComponent,
  },
  {
    path: ':id',
    component: CashflowComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CashflowRoutingModule {}
