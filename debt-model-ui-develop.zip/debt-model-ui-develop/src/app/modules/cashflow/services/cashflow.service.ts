import { Injectable } from '@angular/core';
import { cashflowConstants, APIConstants } from 'src/app/_shared/constants';
import { ScheduleClass, ISchedule, ICashflow } from '../model/cashflow.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CashflowService {

  url = environment.baseURL + APIConstants.debtModelValuation;

  constructor(private http: HttpClient) { }

  getCashflowHorizontalView(payload): Observable<ICashflow> {
    return this.http.get(this.url + `/${payload}/cashflow`).pipe(map(
      (resp: Response) => {
        resp['response']['pivotData'] = [...this.pivotDataTransform(resp['response']?.schedules)];
        return resp['response'];
      }))
  }

  pivotDataTransform = (values: Array<ISchedule>): Array<ICashflow> => {
    const pivotData = [];
    values.sort((a, b) => { return new Date(a.toDate).valueOf() - new Date(b.toDate).valueOf() });
    values?.forEach((data: ISchedule) => {
      for (const prop in new ScheduleClass()) {
        const { fromDate, toDate } = data;
        pivotData.push({ title: cashflowConstants[prop], value: data[prop], fromDate, toDate });
      }
    });
    return pivotData;
  }
}
