import { InputType } from "src/app/_shared/enums";
import { IInputItems } from "../models";

export const panelData: IInputItems[] = [
  { id: 1, name: 'General Details',val: InputType.GENERAL_DETAILS, description: 'Details about the investor, investee, and the instrument' },
];

export const sidebarData: IInputItems[] = [
  {
    id: 2,
    name: 'Interest Details',
    val: InputType.INTEREST_DETAILS,
    description: 'Details about the applicable interest rate type, day count convention, and frequency',
  },
  { id: 3, 
    name: 'Prepayment Details', 
    val: InputType.PREPAYMENT_DETAILS,
    description: 'Details about contractual principal prepayments' },
  {
    id: 4,
    name: 'Credit Rating Details',
    val: InputType.CREDIT_RATING_DETAILS,
    description:
      'Letter grade ratings provided by rating agencies help assess the creditworthiness of the issuer and better price the default risk',
  },
  {
    id: 5,
    name: 'Call Premium',
    val: InputType.CALL_PREMIUM,
    description:
      "Bonds with embedded issuer call options give the issuer the right but not the obligation to 'call' the bond away at a predetermined premium outlined in the Call Premium Schedule",
  },
];
