import { PrincipalRepaymentPattern } from 'src/app/_shared/enums';

export interface PrePaymentDetails {
     id?: number,
     principalRepaymentPattern: PrincipalRepaymentPattern,
     paymentSchedules: PaymentSchedules[]
     debtModelId?: number
}
export interface PaymentSchedules{
  id?: number,
  date: string,
  amount: number,
  prepaymentDetailsId?: number
}
