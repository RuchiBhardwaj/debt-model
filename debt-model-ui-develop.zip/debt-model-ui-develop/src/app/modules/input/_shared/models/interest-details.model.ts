import { InterestType, PaymentFrequency, PaymentType } from "src/app/_shared/enums";

export interface InterestDetails {
      id?: number;
      hasInterestPayment: boolean;
      interestPaidOrAccrued: InterestType,
      interestPaymentType: PaymentType,
      firstInterestPaymentDate: string,
      lastInterestPaymentDate: string,
      interestPaymentFrequency: PaymentFrequency,
      interestPaymentDay: number,
      baseRate: number,
      baseRateCurve: number,
      baseRateFloor: number,
      baseRateCap: number,
      fixedBaseRate: number,
      baseRateSpread: number,
      debtModelId?: number
}
