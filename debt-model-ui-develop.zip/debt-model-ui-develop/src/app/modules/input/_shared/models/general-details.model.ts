import { DayCountConvention } from "src/app/_shared/enums";

export interface GeneralDetails {
      id?: number;
      fundName: string;
      portfolioCompanyName: string;
      debtSecurityName: string;
      originationDate: string;
      valuationDate: string;
      maturityDate: string;
      currency: string;
      principalAmount: number;
      principalOutstanding: number;
      dayCountConvention: DayCountConvention;
      discountRate: number;
      debtModelId?: number;
}
