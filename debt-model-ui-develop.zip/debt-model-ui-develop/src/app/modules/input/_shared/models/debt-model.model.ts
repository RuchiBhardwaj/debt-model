import { InputType } from 'src/app/_shared/enums';
export interface DebtModel {
  analysisDate:	string;
  id?: number;
  inputs:	InputType[];
}
