import { InputType } from "src/app/_shared/enums/input-type.enum";


export interface IInputItems{
    id: number,
    name: string,
    val: InputType,
    description: string
}