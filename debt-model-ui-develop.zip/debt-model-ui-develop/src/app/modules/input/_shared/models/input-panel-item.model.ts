export interface Input {
  icon: string;
  label: string;
}

export interface InputItem {
  id: number;
  title: string;
  status: boolean;
  type:string;
  key:string;
  inputs?: Input[];
}

export interface InputPanel {
  input_item: InputItem[];
}
