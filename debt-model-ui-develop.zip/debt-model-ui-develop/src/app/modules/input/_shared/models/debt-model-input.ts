import { InterestDetails } from './interest-details.model';
import { PrePaymentDetails } from './pre-payment-model';
import { InputType } from "src/app/_shared/enums";
import { GeneralDetails } from "./general-details.model";

export interface DebtModelInput<T> {
  inputType: InputType;
  payload: T
}

export interface DebtModelInputs {
  inputType: InputType;
}

interface IGeneralDetails extends DebtModelInputs {
 payload:GeneralDetails
}

interface IInterestDetails extends DebtModelInputs {
  payload:InterestDetails
}

interface IPrePaymentDetails extends DebtModelInputs {
  payload:PrePaymentDetails
}
