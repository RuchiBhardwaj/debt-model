import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable, Subject } from "rxjs";
import { IApiResponse } from "src/app/_shared/models/response";
import { DebtModel, DebtModelInputs } from "../models";
import { environment } from "src/environments/environment";
import { ICashflow } from "src/app/modules/cashflow/model/cashflow.model";

@Injectable({
  providedIn: 'root'
})
export class DebtModelService {

  public debtModelInputsUpdated = new Subject<any>();
  public debtModel = new Subject<any>();

  constructor(private httpClient: HttpClient) { }

  getDebtModel(debtModelId:number): void {
    this.httpClient.get<IApiResponse<DebtModel>>(environment.baseURL + `valuation/debt-model/${debtModelId}`).subscribe((response)=> {
      this.debtModel.next(response)
    });
  }

  getDebtModelListener(): Observable<IApiResponse<DebtModel>>{
    return this.debtModel.asObservable();
  }

  updateDebtModel(debtModelId:number, payload: {inputs:String[]}): Observable<IApiResponse<DebtModel>>{
    return this.httpClient.put<IApiResponse<DebtModel>>(environment.baseURL + `valuation/debt-model/${debtModelId}`, payload);
  }

  getDebtModelInputs(debtModelId:number) : void {
    this.httpClient.get(environment.baseURL + `valuation/debt-model/${debtModelId}/input`).subscribe((response)=> {
      this.debtModelInputsUpdated.next(response)
    });
  }

  getDebtModelInputsListener() : Observable<IApiResponse<DebtModelInputs[]>>{
    return this.debtModelInputsUpdated.asObservable();
  }

  generateCashFlow(debtModelId:number) : Observable<IApiResponse<ICashflow>>{
    return this.httpClient.post<IApiResponse<ICashflow>>(environment.baseURL + `valuation/debt-model/${debtModelId}/cashflow`, {});
  }

}
