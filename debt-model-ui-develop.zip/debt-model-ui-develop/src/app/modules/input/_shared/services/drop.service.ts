import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { panelData, sidebarData } from '../data/input-dashboard-items';
import { IInputItems } from '../models/input-sidebar-items.model';

@Injectable({
  providedIn: 'root',
})
export class DropService {
  sidebarItems = new BehaviorSubject(Object.assign([],sidebarData));
  sidebarItems$ = this.sidebarItems.asObservable();

  panelItems = new BehaviorSubject(Object.assign([],panelData));
  panelItems$ = this.panelItems.asObservable();

  constructor() {}

  setItemPanelElements(id: Number): void {
    const elem = this.sidebarItems.value.find((el) => el.id === id);
    const idx = this.sidebarItems.value.indexOf(elem);
    let newSidebarArr = [];
    let newPanelArr = [];
    if (idx > -1) {
      this.sidebarItems.value.splice(idx, 1);
      newSidebarArr = this.sidebarItems.value;
    }
    this.sidebarItems.next(newSidebarArr);
    newPanelArr = this.panelItems.value;
    if (newPanelArr.indexOf(elem) === -1) {
      newPanelArr.push(elem);
      this.panelItems.next(newPanelArr);
    }
  }

  deleteItemPanelElements(id: Number): void {
    const elem = this.panelItems.value.find((el) => el.id === id);
    const idx = this.panelItems.value.indexOf(elem);
    let newSidebarArr = [];
    let newPanelArr = [];
    if (idx > -1) {
      this.panelItems.value.splice(idx, 1);
      newPanelArr = this.panelItems.value;
    }
    this.panelItems.next(newPanelArr);
    newSidebarArr = this.sidebarItems.value;
    if (newSidebarArr.indexOf(elem) === -1) {
      newSidebarArr.push(elem);
      this.sidebarItems.next(newSidebarArr);
    }
  }

  getItemPanelsList(): IInputItems[] {
    return this.panelItems.value;
  }

  restoreItemPanelList(): void {
    this.panelItems.next(Object.assign([],panelData));
    this.sidebarItems.next(Object.assign([],sidebarData));
  }
}
