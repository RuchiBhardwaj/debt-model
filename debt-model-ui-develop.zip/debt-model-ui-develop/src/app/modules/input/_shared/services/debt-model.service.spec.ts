import { TestBed } from '@angular/core/testing';

import { DebtModelService } from './debt-model.service';
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe('DebtModelService', () => {
  let service: DebtModelService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(DebtModelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
