import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IApiResponse } from 'src/app/_shared/models/response';
import { DebtModel } from '../models/debt-model.model';
import { InputType } from 'src/app/_shared/enums';

@Injectable({
  providedIn: 'root',
})
export class InputService {
  baseUrl = environment.baseURL + "valuation/debt-model/";

  constructor(private http: HttpClient) {
  }

  getSelectedInputItems(): Observable<Object> {
    return this.http.get('');
  }

  deleteInputItem(debtModelId:number, inputType:string, inputTypeId:number): Observable<IApiResponse<boolean>> {
    return this.http.delete<IApiResponse<boolean>>(environment.baseURL + `valuation/debt-model/${debtModelId}/input/${inputType}/${inputTypeId}`);
  }

  submitGeneralDetails(body, debtId): Observable<Object> {
    return this.http.post(this.baseUrl + debtId + '/input/' + InputType.GENERAL_DETAILS, body);
  }

  submitInterestDetails(interestDetails, debtId): Observable<Object> {
    return this.http.post(this.baseUrl + debtId + '/input/' + InputType.INTEREST_DETAILS, interestDetails);
  }

  submitPrePaymentDetails(prepaymentDetails, debtId): Observable<Object> {
    return this.http.post(this.baseUrl + debtId + '/input/' + InputType.PREPAYMENT_DETAILS, prepaymentDetails);
  }

  updateGeneralDetails(body, debtId, formId): Observable<Object> {
    return this.http.put(this.baseUrl + debtId + '/input/' + InputType.GENERAL_DETAILS + '/' + formId, body);
  }

  updateInterestDetails(body, debtId, formId): Observable<Object> {
    return this.http.put(this.baseUrl + debtId + '/input/' + InputType.INTEREST_DETAILS + '/' + formId, body);
  }

  createDebtModel(payload):Observable<IApiResponse<DebtModel>> {
    return this.http.post<IApiResponse<DebtModel>>(this.baseUrl , payload);
  }

  getDebtModel(id): Observable<Object> {
    return this.http.get(this.baseUrl + id + '/input');
  }

  updatePrePaymentDetails(prepaymentDetails, debtId, formId): Observable<Object> {
    return this.http.put(this.baseUrl + debtId + '/input/' + InputType.PREPAYMENT_DETAILS + '/' + formId, prepaymentDetails);
  }

  getDebtModelInputs(debtId) {
    return this.http.get(this.baseUrl+debtId);
  }
}
