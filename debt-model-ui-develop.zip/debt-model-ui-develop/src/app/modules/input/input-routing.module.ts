import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { InputDashboardComponent, InputLandingComponent, InputDetailsCardComponent } from './components';

const routes: Routes = [
  {
    path: '',
    component: InputDashboardComponent,
  },
  {
    path: ':id',
    component: InputDashboardComponent,
  },
  {
    path: ':id/:key',
    component: InputLandingComponent,

    children: [
      {
        path: '',
        component: InputDetailsCardComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InputRoutingModule {}
