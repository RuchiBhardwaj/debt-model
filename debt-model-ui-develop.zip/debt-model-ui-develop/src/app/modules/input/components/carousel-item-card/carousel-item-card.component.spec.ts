import { RouterTestingModule } from '@angular/router/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarouselItemCardComponent } from './carousel-item-card.component';
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe('CarouselItemCardComponent', () => {
  let component: CarouselItemCardComponent;
  let fixture: ComponentFixture<CarouselItemCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      declarations: [CarouselItemCardComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarouselItemCardComponent);
    component = fixture.componentInstance;
    component.panelItem = {};
    component.selectedInput = 'test';
    component.inputKey = 'test';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
