import { ActivatedRoute } from '@angular/router';
import { DebtModelService } from './../../_shared/services/debt-model.service';
import { IApiResponse } from './../../../../_shared/models/response';
import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { DebtModelInputs } from "../../_shared/models";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";

@Component({
  selector: 'input-carousel-item-card',
  templateUrl: './carousel-item-card.component.html',
  styleUrls: ['./carousel-item-card.component.scss'],
})
export class CarouselItemCardComponent implements OnInit, OnDestroy {
  @Input() panelItem;
  @Input() selectedInput;
  @Input() inputKey;

  private debtModelInputs:DebtModelInputs[]
  public status:boolean
  private debtModelId;
  private onDestroy$ = new Subject();

  constructor(private debtModelService: DebtModelService, private activatedRoute: ActivatedRoute) {
  }

  ngOnInit(): void{
    this.getDebtModelId();
  }

  private getDebtModelId(){
      this.debtModelId = this.activatedRoute.snapshot.paramMap.get('id');
      this.getDebtModelInputs();
  }

  private getDebtModelInputs():void{
    this.debtModelService.getDebtModelInputs(this.debtModelId)
    this.debtModelService.getDebtModelInputsListener()
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((data:IApiResponse<DebtModelInputs[]>) => {
      this.debtModelInputs = data.response
      this.getInputItemStatus();
    });
  }

  private getInputItemStatus(): void{
    const itemsWithCompleteStatus =  this.debtModelInputs.map(input => input.inputType);
    this.status = itemsWithCompleteStatus.includes(this.panelItem.type)
  }

  ngOnDestroy():void{
    this.onDestroy$.next();
    this.onDestroy$.complete();
  }
}
