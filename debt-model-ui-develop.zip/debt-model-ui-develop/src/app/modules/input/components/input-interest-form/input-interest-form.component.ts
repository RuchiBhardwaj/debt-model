import { DebtModelService } from './../../_shared/services/debt-model.service';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { interestConstants } from 'src/app/_shared/constants';
import { InputService } from 'src/app/modules/input/_shared/services/input.service';
import { InputType } from 'src/app/_shared/enums';
import { Subscription } from 'rxjs';
import { DialogUtility } from '@syncfusion/ej2-popups';


@Component({
  selector: 'input-interest-form',
  templateUrl: './input-interest-form.component.html',
  styleUrls: ['./input-interest-form.component.scss'],
})
export class InputInterestFormComponent implements OnInit{
  form: FormGroup;
  selectedValue = 'Yes';
  selectedBaseRate = '';
  public interestFormConstant = interestConstants;
  public generalDetails;
  public maturityDate;
  public originationDate: string;
  public debtId;
  public formId;
  public isFormFilled:boolean=false;
  public prepaymentExists:boolean;
  private sub = new Subscription();
  DialogObj: any;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private inputService: InputService,
    private debtModelService: DebtModelService,
    private activatedRoute: ActivatedRoute) {  
    this.form = this.formBuilder.group({
      interestPayment: [null],
      interestPaid: [null, [Validators.required]],
      interestPaymentType: [null, [Validators.required]],
      firstInterestDate: [null, [Validators.required]],
      lastInterestDate: [null, [Validators.required]],
      interestPaymentDay: [null, [Validators.required]],
      interestFrequency: [null, [Validators.required]],
      baseRate: [null,],
      liborCurve: [null,],
      baseRateFloor: [null],
      baseRateCap: [null],
      fixedBaseRate: [null, [Validators.required, Validators.min(0)]],
      spreadBaseRate: [null, [Validators.min(0)]],
    },
      {
        validator: Validators.compose([this.dateLessThan('firstInterestDate', 'lastInterestDate',
          { firstinterestdate: true }),
        this.dateGreaterThan('lastInterestDate', 'firstInterestDate', { lastinterestdate: true }
        )
        ])
      }
    );
    this.selectedBaseRate = 'LIBOR';
    this.activatedRoute.params.subscribe((params) => {
      this.debtId = params.id;
    });
    this.getInterestDetails(this.debtId);
  }

  ngOnInit() {
    this.inputService.getDebtModelInputs(this.debtId).subscribe(res=> {
      const details = JSON.parse(JSON.stringify(res));
      this.prepaymentExists = (details.response.inputs).includes(InputType.PREPAYMENT_DETAILS)
    })
    this.selectedValue = 'Yes';
    if(localStorage.getItem('baseRate')!=null){
      this.selectedBaseRate=localStorage.getItem('baseRate');
    }
  }

  submitForm(): void {
    localStorage.setItem("baseRate", this.form.controls['baseRate'].value);
    const body = {
      "inputType":InputType.INTEREST_DETAILS,
      "payload":{
      "hasInterestPayment": this.form.get('interestPayment').value,
      "interestPaidOrAccrued": this.form.get('interestPaid').value,
      "interestPaymentType": this.form.get('interestPaymentType').value,
      "firstInterestPaymentDate": this.form.get('firstInterestDate').value,
      "lastInterestPaymentDate": this.form.get('lastInterestDate').value,
      "interestPaymentFrequency": this.form.get('interestFrequency').value,
      "interestPaymentDay": this.form.get('interestPaymentDay').value,
      "baseRate": null,
      "baseRateCurve": null,
      "baseRateFloor": this.form.get('baseRateFloor').value ?? 0,
      "baseRateCap": this.form.get('baseRateCap').value ?? 0,
      "fixedBaseRate": this.form.get('fixedBaseRate').value ?? null,
      "baseRateSpread": this.form.get('spreadBaseRate').value ?? null,
    }
  }

    this.sub.add(this.inputService.submitInterestDetails(body, this.debtId).subscribe(res => {
      this.debtModelService.getDebtModelInputs(this.debtId)
      if(this.prepaymentExists){
      this.router.navigate(['input/'+this.debtId+'/prepaymentDetails']);
      } else {
         this.openSuccessAlert();
      }
    }))
  }

  onOptionsSelected(event): void {
    this.selectedValue = event.target.value;
  }

  baseRateSelected(event): void {
    this.selectedBaseRate = event.target.value;
  }

  dateGreaterThan(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      const date1 = c.get(dateField1).value;
      const date2 = c.get(dateField2).value;
      if (date1 !== null && date2 !== null && date1 < date2) {
        return validatorField;
      }
      return null;
    };
  }

  dateLessThan(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      const date1 = c.get(dateField1).value;
      const date2 = c.get(dateField2).value;
      if (date1 !== null && date2 !== null && date1 > date2) {
        return validatorField;
      }
      return null;
    };
  }

  dateLessThanValidator(
    dateField: string,
    validatorField: { [key: string]: boolean }
  ): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      const date2 = dateField;
      const date1 = c.value;
      if (date1 !== null && date2 !== null && date1 < date2) {
        return validatorField;
      }
      return null;
    };
  }

  dateGreaterThanValidator(
    dateField: string,
    validatorField: { [key: string]: boolean }
  ): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      const date2 = dateField;
      const date1 = c.value;
      if (date1 !== null && date2 !== null && date1 > date2) {
        return validatorField;
      }
      return null;
    };
  }

  getInterestDetails(id):void {
    this.inputService.getDebtModel(id).subscribe(response => {
      let details = JSON.parse(JSON.stringify(response));
      let interestDetails=(details.response.find( record => record.inputType === "INTEREST_DETAILS"));
      let generalDetails=(details.response.find( record => record.inputType === "GENERAL_DETAILS"));
      if(generalDetails){
        this.maturityDate=generalDetails.payload.maturityDate;
        this.originationDate= String(generalDetails.payload.originationDate);
        this.form.controls["lastInterestDate"].setValue(this.maturityDate);
        this.form.controls["firstInterestDate"].setValidators([this.dateGreaterThanValidator(this.maturityDate, { firstbeyondmaturity: true }),
          this.dateLessThanValidator(this.originationDate, { firstInterestDateBeforeOrigination: true })]);
        this.form.controls["lastInterestDate"].setValidators(this.dateGreaterThanValidator(this.maturityDate, { lastbeyondmaturity: true }));
      }
      if (interestDetails) {
        this.setFormValue(interestDetails.payload)
        this.formId = interestDetails.payload.id;
        this.isFormFilled=true;
      }
    })
  }

  setFormValue(interestDetails):void {
    this.form.patchValue(
      {
        interestPayment: 'Yes',
        interestPaid: interestDetails.interestPaidOrAccrued,
        interestPaymentType: interestDetails.interestPaymentType,
        firstInterestDate: interestDetails.firstInterestPaymentDate,
        lastInterestDate: interestDetails.lastInterestPaymentDate,
        interestPaymentDay: interestDetails.interestPaymentDay,
        interestFrequency: interestDetails.interestPaymentFrequency,
        baseRate: interestDetails.baseRate?? localStorage.getItem('baseRate'),
        liborCurve: interestDetails.baseRateCurve,
        baseRateFloor: interestDetails.baseRateFloor,
        baseRateCap: interestDetails.baseRateCap,
        fixedBaseRate: interestDetails.fixedBaseRate,
        spreadBaseRate: interestDetails.baseRateSpread
      }
    )
  }

  setFormBody(): Object{
    const body = {
      "inputType":InputType.INTEREST_DETAILS,
      "payload":{
      "hasInterestPayment": true,
      "interestPaidOrAccrued": this.form.get('interestPaid').value,
      "interestPaymentType": this.form.get('interestPaymentType').value,
      "firstInterestPaymentDate": this.form.get('firstInterestDate').value,
      "lastInterestPaymentDate": this.form.get('lastInterestDate').value,
      "interestPaymentFrequency": this.form.get('interestFrequency').value,
      "interestPaymentDay": this.form.get('interestPaymentDay').value,
      "baseRate": null,
      "baseRateCurve": null,
      "baseRateFloor": this.form.get('baseRateFloor').value ?? 0,
      "baseRateCap": this.form.get('baseRateCap').value ?? 0,
      "fixedBaseRate": this.form.get('fixedBaseRate').value ?? null,
      "baseRateSpread": this.form.get('spreadBaseRate').value ?? null,
      "id":this.formId,
    }
  }
    return body;
  }

  updateInterestDetails():void {
    localStorage.setItem("baseRate", this.form.controls['baseRate'].value);
    const body = this.setFormBody();
    this.sub.add(this.inputService.updateInterestDetails(body, this.debtId, this.formId).subscribe(res => {
      if(this.prepaymentExists){
      this.router.navigate(['input/' + this.debtId + '/prepaymentDetails']);
      } else {
            this.openSuccessAlert();
      }
    }))
  }


  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  openSuccessAlert(): void {
    this.DialogObj = DialogUtility.alert({
      title: `<div class="icon-placement"><em class="fa fa-check-circle" aria-hidden="true"></em></div><div>Thank You For your Response</div>`,
      content: 'All responses are submitted successfully! Click on the "Submit" button to move to next screen.',
      okButton: {
        text: 'OK',
        click: this.dismiss.bind(this),
        cssClass: 'btn-success',
      },
      showCloseIcon: false,
      closeOnEscape: false,
    });
  }

  dismiss(): void {
    this.DialogObj.hide();
  }
}
