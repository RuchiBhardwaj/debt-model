import { AfterViewChecked, Component, OnDestroy, OnInit } from '@angular/core';
import { sidebarData } from '../../_shared/data/input-dashboard-items';
import { Draggable } from '@syncfusion/ej2-base';
import { ViewChildren } from '@angular/core';
import { QueryList } from '@angular/core';
import { DropService } from '../../_shared/services/drop.service';
import { DragStopArgs } from '@syncfusion/ej2-layouts';
import { Subject, Subscription } from 'rxjs';
import { IInputItems } from '../../_shared/models';
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";

@Component({
  selector: 'input-sidebar',
  templateUrl: './input-sidebar.component.html',
  styleUrls: ['./input-sidebar.component.scss'],
})
export class InputSidebarComponent implements OnInit, AfterViewChecked, OnDestroy {
  items:IInputItems[] = sidebarData;
  filteredItems = JSON.parse(JSON.stringify(this.items));
  searchVal = '';
  subscription = new Subscription();
  searchSubscription = new Subscription();
  debounce:any;
  @ViewChildren('ele')
  element: QueryList<any>;
  searchTextChanged = new Subject<string>();

  constructor(private dropService: DropService) {}

  ngOnInit(): void {
    this.subscription = this.dropService.sidebarItems$.subscribe((val) => {
      this.items = val;
      this.onSearch();
    });
    this.searchSubscription = this.searchTextChanged
        .debounceTime(100) //debounce for 0.1s or 100ms
        .distinctUntilChanged()
        .subscribe(() => this.onSearch());
    }  

  ngAfterViewChecked(): void {
    this.element.toArray().forEach((elem) => {
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      new Draggable(elem.nativeElement, {
        clone: false,
        dragStop: (e: DragStopArgs) => {
          e.element.style.setProperty('position', 'relative');
          e.element.style.setProperty('top', 'unset');
          e.element.style.setProperty('left', 'unset');
        },
      });
    });
  }

  onSearch(): void {
    if (this.searchVal === '') {
      this.filteredItems = JSON.parse(JSON.stringify(this.items));
    } else {
      this.filteredItems = [];
      this.items
        .filter((elem) => String(elem.name).toLocaleLowerCase().search(this.searchVal.toLocaleLowerCase()) > -1)
        .forEach((val) => this.filteredItems.push(val));
    }
  }

  selectItem(id: Number): void{
    this.dropService.setItemPanelElements(id);
  }

  search(){
    this.searchTextChanged.next(this.searchVal);
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
    this.searchSubscription.unsubscribe();
  }

  
}
