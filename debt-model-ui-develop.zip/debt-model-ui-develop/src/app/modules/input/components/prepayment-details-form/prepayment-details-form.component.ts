import { ExcelService } from './../../../../_shared/services/excel/excel.service';
import { DebtModelService } from './../../_shared/services/debt-model.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { InputService } from '../../_shared/services/input.service';
import { DialogUtility } from '@syncfusion/ej2-popups';
import { InputType } from 'src/app/_shared/enums';
import { Subscription } from 'rxjs';
import { interestConstants } from 'src/app/_shared/constants';
import { PrincipalRepaymentPattern } from 'src/app/_shared/enums';

type TwoDimensionalArray<T> = T[][];

@Component({
  selector: 'input-prepayment-details-form',
  templateUrl: './prepayment-details-form.component.html',
  styleUrls: ['./prepayment-details-form.component.scss'],
})
export class PrepaymentDetailsFormComponent implements OnInit {
  dataLength = 0;
  data: TwoDimensionalArray<any> = [
    [1, 2],
    [3, 4],
  ];
  fileLength = 0;
  public debtId;
  public paymentJSON;
  public formId;
  public isFormFilled: boolean = false;
  public prepaymentData;
  constantMessages = interestConstants;
  DialogObj: any;
  private sub = new Subscription();
  public uploadedData;
  public validFile = true;

  ngOnInit(): void {
    this.fileLength = 0;
    this.activatedRoute.params.subscribe((params) => {
      this.debtId = params.id;
    });

    this.getPrepaymentDetails(this.debtId);
  }

  constructor(private router: Router,
    private inputService: InputService,
    private debtModelService: DebtModelService,
    private excelService: ExcelService,
    private activatedRoute: ActivatedRoute
    ) {

  }

  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  fileName: string = 'PreSheet.xlsx';

  onFileChange(evt: any) {
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error(interestConstants.multipleFileError);
    this.fileLength = target.files.length;
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      // read workbook
      const byteStream: string = e.target.result;
      const workBook: XLSX.WorkBook = XLSX.read(byteStream, { type: 'binary' });

      // grab first sheet
      const workSheetName = workBook.SheetNames[0];
      const workSheet: XLSX.WorkSheet = workBook.Sheets[workSheetName];

      // save data
      this.data = XLSX.utils.sheet_to_json(workSheet, { header: 1, raw: false }) as TwoDimensionalArray<any>;
      this.formatData(this.data);
      this.dataLength = this.data.length;
    };
    this.dataLength = this.data.length;
    reader.readAsBinaryString(target.files[0]);
  }

  submitForm(): void {
    var filtered = this.data.filter(item => item.length != 0);
    this.paymentJSON = filtered.slice(2,).map(function (value, key) {
      let date = new Date(value[0]).toISOString().slice(0, 10);
      return {
        "Date": date,
        "Amount": value[1]
      }
    });
    const body = {
      "inputType": InputType.PREPAYMENT_DETAILS,
      "payload": {
        "principalRepaymentPattern": PrincipalRepaymentPattern.INTERIM_FIXED_EQUAL_PAYMENTS,
        "paymentSchedules": this.paymentJSON
      }
    }
    this.sub.add(this.inputService.submitPrePaymentDetails(body, this.debtId).subscribe(res => {
      this.debtModelService.getDebtModelInputs(this.debtId)
      this.openSuccessAlert();
    }))
  }

  getPrepaymentDetails(debtId): void {
    this.inputService.getDebtModel(debtId).subscribe(response => {
      const details = JSON.parse(JSON.stringify(response));
      const prepaymentDetails = (details.response.find(record => record.inputType == InputType.PREPAYMENT_DETAILS));
      if (prepaymentDetails.payload.paymentSchedules.length) {
        this.prepaymentData = prepaymentDetails.payload.paymentSchedules;
        this.formId = prepaymentDetails.payload.id;
        this.isFormFilled = true;
      }
    });
  }

  updatePrepaymentDetails(): void {
    var filtered = this.data.filter(item => item.length != 0);
    this.paymentJSON = filtered.slice(2,).map(function (value, key) {
      let date = new Date(value[0]).toISOString().slice(0, 10);
      return {
        "Date": date,
        "Amount": value[1]
      }
    });
    const body = {
      "inputType": InputType.PREPAYMENT_DETAILS,
      "payload": {
        "principalRepaymentPattern": PrincipalRepaymentPattern.INTERIM_FIXED_EQUAL_PAYMENTS,
        "paymentSchedules": this.paymentJSON,
        "id": this.formId
      }
    }
    this.sub.add(this.inputService.updatePrePaymentDetails(body, this.debtId, this.formId).subscribe(res => {
      this.openSuccessAlert();
    }))

  }

  openSuccessAlert(): void {
    this.DialogObj = DialogUtility.alert({
      title: `<div class="icon-placement"><em class="fa fa-check-circle" aria-hidden="true"></em></div><div>Thank You For your Response</div>`,
      content: 'All responses are submitted successfully! Click on the "Submit" button to move to next screen.',
      okButton: {
        text: 'OK',
        click: this.dismiss.bind(this),
        cssClass: 'btn-success',
      },
      showCloseIcon: false,
      closeOnEscape: false,
    });
  }

  dismiss(): void {
    this.DialogObj.hide();
  }

  downloadPrePaymentTemplate():void {
    this.excelService.exportExcelFile('prepayment_template');
 }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  checkValidDate(): boolean {
    for (let element of this.uploadedData) {
      if (!(!isNaN(new Date(element.Date).getDate()) != false && isNaN(element.Amount) != true)) {
        return false;
      }
    }
    return true;
  }

  formatData(data): void {
    // take the row of data and amount and create a new JSON
    var filtered = data.filter(item => item.length != 0);
    this.uploadedData = filtered.slice(2,).map(function (value, key) {
      return {
        "Date": value[0],
        "Amount": value[1]
      }
    });
    this.validFile = this.checkValidDate();
    if (!this.validFile) {
      this.alertError(interestConstants.fileReadingError);
      this.ngOnInit();
    }
  }

  alertError(errorMessage): void {
    this.DialogObj = DialogUtility.alert({
      title: `<div>An error occurred while reading the sheet.</div>`,
      content: errorMessage,
      okButton: {
        text: 'OK',
        click: this.dismiss.bind(this),
        cssClass: 'btn-info',
      },
      showCloseIcon: false,
      closeOnEscape: false,
    });
  }

}
