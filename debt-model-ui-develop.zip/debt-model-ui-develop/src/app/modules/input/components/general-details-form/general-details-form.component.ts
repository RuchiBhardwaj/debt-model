import { DebtModelService } from './../../_shared/services/debt-model.service';
import { DialogUtility } from '@syncfusion/ej2-popups';
import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { currencyConstants, interestConstants } from 'src/app/_shared/constants';
import { InputService } from '../../_shared/services/input.service';
import { InputType } from 'src/app/_shared/enums';
import { Subscription } from 'rxjs';


@Component({
  selector: 'input-general-details-form',
  templateUrl: './general-details-form.component.html',
  styleUrls: ['./general-details-form.component.scss'],
})
export class GeneralDetailsFormComponent {
  form: FormGroup;
  DialogObj;

  public data: string[] = currencyConstants;
  public yearFrac = interestConstants.dayTimeConvention;
  public debtId;
  public formId;
  public isFormFilled:boolean=false;
  private sub = new Subscription();
  public constant=interestConstants;
  prepaymentExists: boolean;
  interestExists: boolean;

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private inputService: InputService,
    private detModelService: DebtModelService,
    private activatedRoute:ActivatedRoute) {
    // TODO: Using a deprecated method?
    this.form = this.formBuilder.group(
      {
        fundName: [null, [Validators.required]],
        portfoliCompanyName: [null, [Validators.required]],
        debtSecurityName: [null, [Validators.required]],
        originationDate: [null, [Validators.required]],
        valuationDate: [null, [Validators.required]],
        maturityDate: [null, [Validators.required]],
        currency: [null],
        principalAmount: [null, [Validators.min(1), Validators.required]],
        principalOutstanding: [null, [Validators.min(0), Validators.max(100), Validators.required]],
        dayCountConvention: [null,],
      },
      {
        validator: Validators.compose([
          this.dateGreaterThan('maturityDate', 'originationDate', {
            maturitydate: true,
          }),
          this.dateLessThan('valuationDate', 'maturityDate', {
            valuationdate: true,
          }),
        ]),
      }
    );
    this.activatedRoute.params.subscribe((params) => {
      this.debtId = params.id;
    });
  }

  ngOnInit() {
    this.getGeneralDetails(this.debtId);
    this.inputService.getDebtModelInputs(this.debtId).subscribe(res=> {
      const details = JSON.parse(JSON.stringify(res));
      this.prepaymentExists = (details.response.inputs).includes(InputType.PREPAYMENT_DETAILS);
      this.interestExists = (details.response.inputs).includes(InputType.INTEREST_DETAILS);
    })
  }

  submitForm() {
    const body = {
      "inputType":InputType.GENERAL_DETAILS,
      "payload": {
      "fundName": this.form.get('fundName').value,
      "portfolioCompanyName": this.form.get('portfoliCompanyName').value,
      "debtSecurityName": this.form.get('debtSecurityName').value,
      "originationDate": this.form.get('originationDate').value,
      "valuationDate": this.form.get('valuationDate').value,
      "maturityDate": this.form.get('maturityDate').value,
      "currency": this.form.get('currency').value,
      "principalAmount": this.form.get('principalAmount').value,
      "principalOutstanding": this.form.get('principalOutstanding').value,
      "dayCountConvention": this.form.get('dayCountConvention').value,
      "discountRate": 6.12,
    }
  }
    this.sub.add(this.inputService.submitGeneralDetails(body, this.debtId).subscribe(res => {
      this.detModelService.getDebtModelInputs(this.debtId)
      if(this.interestExists){
      this.router.navigate(['input/'+this.debtId+'/interestDetails']);
      } else if (!this.interestExists && this.prepaymentExists) {
        this.router.navigate(['input/'+this.debtId+'/prepaymentDetails']);
      } else {
        this.openSuccessAlert();
      }
    }))
    // TODO: async method
  }

  openSuccessAlert(): void {
    this.DialogObj = DialogUtility.alert({
      title: `<div class="icon-placement"><em class="fa fa-check-circle" aria-hidden="true"></em></div><div>Thank You For your Response</div>`,
      content: 'All responses are submitted successfully! Click on the "Submit" button to move to next screen.',
      okButton: {
        text: 'OK',
        click: this.dismiss.bind(this),
        cssClass: 'btn-success',
      },
      showCloseIcon: false,
      closeOnEscape: false,
    });
  }

  dismiss(): void {
    this.DialogObj.hide();
  }

  changeCurrency(event: { value: any }): void {}

  isFormValid(): boolean {
    return this.form.disabled ? true : this.form.valid;
  }

  dateGreaterThan(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      const date1 = c.get(dateField1).value;
      const date2 = c.get(dateField2).value;
      if (date1 !== null && date2 !== null && date1 < date2) {
        return validatorField;
      }
      return null;
    };
  }

  dateLessThan(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      const date1 = c.get(dateField1).value;
      const date2 = c.get(dateField2).value;
      if (date1 !== null && date2 !== null && date1 > date2) {
        return validatorField;
      }
      return null;
    };
  }

  getGeneralDetails(id):void{
    this.inputService.getDebtModel(id).subscribe(response => {
      let details= JSON.parse(JSON.stringify(response));
      let generalDetails=(details.response.find( record => record.inputType === "GENERAL_DETAILS"));
      if(generalDetails){
      this.setFormValue(generalDetails.payload)
      this.formId=generalDetails.payload.id;
      this.isFormFilled=true;
      }
    })
  }

  setFormValue(generalDetails):void{
    this.form.patchValue({
      fundName: generalDetails.fundName,
        portfoliCompanyName: generalDetails.portfolioCompanyName ,
        debtSecurityName: generalDetails.debtSecurityName,
        originationDate: generalDetails.originationDate,
        valuationDate: generalDetails.valuationDate,
        maturityDate: generalDetails.maturityDate,
        currency: generalDetails.currency,
        principalAmount: generalDetails.principalAmount,
        principalOutstanding: generalDetails.principalOutstanding,
        dayCountConvention: generalDetails.dayCountConvention,
    })
  }

  setFormBody(): Object{
    const body = {
      "inputType":InputType.GENERAL_DETAILS,
      "payload": {
      "fundName": this.form.get('fundName').value,
      "portfolioCompanyName": this.form.get('portfoliCompanyName').value,
      "debtSecurityName": this.form.get('debtSecurityName').value,
      "originationDate": this.form.get('originationDate').value,
      "valuationDate": this.form.get('valuationDate').value,
      "maturityDate": this.form.get('maturityDate').value,
      "currency": this.form.get('currency').value,
      "principalAmount": this.form.get('principalAmount').value,
      "principalOutstanding": this.form.get('principalOutstanding').value,
      "dayCountConvention": this.form.get('dayCountConvention').value,
      "discountRate": 6.12,
      "id":this.formId
    }
  }
    return body;
  }

  updateGeneralDetails():void{
    const body = this.setFormBody();
    this.sub.add(this.inputService.updateGeneralDetails(body, this.debtId, this.formId).subscribe(res => {
      if(this.interestExists){
        this.router.navigate(['input/'+this.debtId+'/interestDetails']);
        } else if (!this.interestExists && this.prepaymentExists) {
          this.router.navigate(['input/'+this.debtId+'/prepaymentDetails']);
        } else {
          this.openSuccessAlert();
        }
    }));
  }


  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }


}
