import { InputType } from './../../../../_shared/enums/input-type.enum';
import { DebtModelService } from './../../_shared/services/debt-model.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { IApiResponse } from "src/app/_shared/models/response";
import { DebtModel, DebtModelInputs } from "../../_shared/models";

@Component({
  selector: 'input-input-landing',
  templateUrl: './input-landing.component.html',
  styleUrls: ['./input-landing.component.scss'],
})
export class InputLandingComponent implements OnInit, OnDestroy{
  public debtModelId;
  private onDestroy$ = new Subject();
  public inputTypes: InputType[];
  private inputTypesWithData;
  public debtModelInputs: DebtModelInputs[];
  public allFormsSubmitted
  constructor(private debtModelService: DebtModelService, private activatedRoute: ActivatedRoute, private router: Router) {}

  ngOnInit(): void{
    this.getdebtModelId();
  }

  private getdebtModelId(): void{
      this.debtModelId = this.activatedRoute.snapshot.paramMap.get('id');
      this.getDebtModel();
  }

  generateCashFlow(): void{
    this.debtModelService.generateCashFlow(this.debtModelId)
    .pipe(takeUntil(this.onDestroy$))
    .subscribe(()=> {
      this.router.navigate(['cashflow',this.debtModelId])
    })
  }

  private getDebtModel(): void {
    this.debtModelService.getDebtModel(this.debtModelId)
    this.debtModelService.getDebtModelListener()
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((data:IApiResponse<DebtModel>)=> {
        this.inputTypes = data.response.inputs;
        this.getDebtModelInputs();
    })
  }

  private getDebtModelInputs(): void{
    this.debtModelService.getDebtModelInputs(this.debtModelId)
    this.debtModelService.getDebtModelInputsListener()
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((data:IApiResponse<DebtModelInputs[]>) => {
      this.debtModelInputs = data.response
      this.inputTypesWithData = this.getSubmittedInputTypes();
      this.allFormsSubmitted = this.checkAllInputsSubmitted();
    });
  }

  private getSubmittedInputTypes(): InputType[]{
    return this.debtModelInputs.map(input => input.inputType);
  }

  private checkAllInputsSubmitted() {
      return this.inputTypes.every(v => this.inputTypesWithData.includes(v))
  }

  ngOnDestroy():void{
    this.onDestroy$.next();
    this.onDestroy$.complete();
  }
}
