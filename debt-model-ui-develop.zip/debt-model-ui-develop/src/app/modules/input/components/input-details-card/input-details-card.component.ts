import { HelperService } from './../../../../_shared/services/helper/helper.service';
import { DebtModelService } from './../../_shared/services/debt-model.service';
import { InputItem } from '../../_shared/models/input-panel-item.model';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as inputDetails from '../../_shared/data/input-details.json';
import { ActivatedRoute } from '@angular/router';
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { IApiResponse } from "src/app/_shared/models/response";
import { DebtModelInputs } from "../../_shared/models";

@Component({
  selector: 'input-details-card',
  templateUrl: './input-details-card.component.html',
  styleUrls: ['./input-details-card.component.scss'],
})
export class InputDetailsCardComponent implements OnInit, OnDestroy {
  public inputPanelItem: InputItem;
  private debtModelId;
  private debtModelInputs;
  private inputType;
  private onDestroy$ = new Subject();
  public status;
  constructor(private activatedRoute: ActivatedRoute,
              private helperService: HelperService,
              private debtModelService: DebtModelService) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params) => {
      this.debtModelId = params.id
      this.inputType = params.key
      this.getInputPanelItem(params.key);
      this.getDebtModelInputs();
    });
  }

  private getInputPanelItem(key): void {
    this.inputPanelItem = inputDetails.default.input_item.find((x) => x.key === key);
  }

  //TODO Defining common logic for status update in carousel card & input details card
  private getDebtModelInputs():void{
    this.debtModelService.getDebtModelInputs(this.debtModelId)
    this.debtModelService.getDebtModelInputsListener()
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((data:IApiResponse<DebtModelInputs[]>) => {
      this.debtModelInputs = data.response
      this.getInputItemStatus();
    });
  }

  private getInputItemStatus(): void{
    const itemsWithCompleteStatus =  this.debtModelInputs.map(input => input.inputType);
    this.status = itemsWithCompleteStatus.includes(this.helperService.convertCamelCaseToSnakeCase(this.inputType))
  }

  ngOnDestroy():void{
    this.onDestroy$.next();
    this.onDestroy$.complete();
  }
}
