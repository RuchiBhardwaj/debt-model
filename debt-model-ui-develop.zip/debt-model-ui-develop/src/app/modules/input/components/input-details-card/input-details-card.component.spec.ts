import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InputDetailsCardComponent } from './input-details-card.component';

describe('InputDetailsCardComponent', () => {
  let component: InputDetailsCardComponent;
  let fixture: ComponentFixture<InputDetailsCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [InputDetailsCardComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InputDetailsCardComponent);
    component = fixture.componentInstance;
    component.inputPanelItem = {id: 0, inputs: [], status: false, title: '', type:'',key:''};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
