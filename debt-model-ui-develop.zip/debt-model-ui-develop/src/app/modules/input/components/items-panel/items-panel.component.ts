import { HelperService } from './../../../../_shared/services/helper/helper.service';
import { InputService } from 'src/app/modules/input/_shared/services/input.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DebtModelService } from './../../_shared/services/debt-model.service';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { DialogUtility } from '@syncfusion/ej2-popups';
import { takeUntil } from "rxjs/operators";
import { IApiResponse } from "src/app/_shared/models/response";
import { DebtModelInputs, DebtModel } from "../../_shared/models";
import { Subject } from "rxjs";
import { InputType } from "src/app/_shared/enums";

@Component({
  selector: 'input-items-panel',
  templateUrl: './items-panel.component.html',
  styleUrls: ['./items-panel.component.scss'],
})
export class ItemsPanelComponent implements OnInit, OnDestroy {
  @Input() inputTypes: InputType[];
  @Input() debtModelInputs:DebtModelInputs[];

  public DialogObj;
  private debtModelId;
  public inputType;
  private inputDetails;
  private onDestroy$ = new Subject();

  constructor(private debtModelService: DebtModelService,
              private helperService: HelperService,
              private activatedRoute: ActivatedRoute,
              private router: Router,
              private inputService: InputService) { }

  ngOnInit(): void{
    this.getRouteParams();
  }

  private getRouteParams(): void{
    this.activatedRoute.params
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((params) => {
      this.debtModelId = parseInt(params.id)
      this.inputType = params.key
    });
  }

  private getInputsWithDetails(){
    const inputDetails  = this.debtModelInputs.find(input => input.inputType === this.helperService.convertCamelCaseToSnakeCase(this.inputType))
    return inputDetails
  }

  public deleteItem(): void {
    this.inputDetails = this.getInputsWithDetails();
    this.DialogObj = DialogUtility.confirm({
      title: `<div class="icon-placement"><em class=" fa fa-trash"></em></div><div>Are You Sure?</div>`,
      content: "Are you sure want to delete this item? You can't undo this action",
      okButton: {
        text: 'Delete',
        click: this.deleteConfirmation.bind(this),
        cssClass: 'btn-danger',
      },
      cancelButton: { text: 'Cancel', click: this.cancel.bind(this) },
      showCloseIcon: false,
      closeOnEscape: false,
    });
  };

  private deleteConfirmation(): void {
    if(this.inputDetails){
      this.inputService.deleteInputItem(this.debtModelId, this.helperService.convertCamelCaseToSnakeCase(this.inputType), this.inputDetails.payload.id)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(()=> {
        this.debtModelService.getDebtModel(this.debtModelId)
        this.router.navigate(['input', this.debtModelId, 'generalDetails'])
      })
    }else{
      let inputArray = []
      const payload = {
        inputs: this.helperService.removeItem(this.inputTypes, this.helperService.convertCamelCaseToSnakeCase(this.inputType))
      }
      this.debtModelService.updateDebtModel(this.debtModelId, payload)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe((response: IApiResponse<DebtModel>) => {
        this.debtModelService.getDebtModel(this.debtModelId)
        inputArray = response.response.inputs
        this.router.navigate(['input', this.debtModelId, this.helperService.convertSnakeCaseToCamelCase(inputArray.pop())])
      });
    }

    this.DialogObj.hide();
  }

  private cancel(): void {
    this.DialogObj.hide();
  }

  ngOnDestroy(): void {
    this.onDestroy$.next();
    this.onDestroy$.complete();
  }
}
