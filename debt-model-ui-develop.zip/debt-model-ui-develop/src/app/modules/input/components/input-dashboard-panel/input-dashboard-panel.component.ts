import { AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Droppable, DropEventArgs } from '@syncfusion/ej2-base';
import { Subscription } from 'rxjs';
import { panelData } from '../../_shared/data/input-dashboard-items';
import { IInputItems } from '../../_shared/models/input-sidebar-items.model';
import { DropService } from '../../_shared/services/drop.service';
import { InputService } from '../../_shared/services/input.service';

@Component({
  selector: 'input-dashboard-panel',
  templateUrl: './input-dashboard-panel.component.html',
  styleUrls: ['./input-dashboard-panel.component.scss'],
})
export class InputDashboardPanelComponent implements OnInit, AfterViewInit, OnDestroy {
  public items: IInputItems[] = panelData;
  private subscription$ = new Subscription();
  @ViewChild('droppable', { static: false }) element: any;

  constructor(private route: Router,
              private dropService: DropService,
              private inputService: InputService) {}

  ngOnInit(): void {
    this.subscription$ = this.dropService.panelItems$.subscribe((val) => (this.items = val));
    this.dropService.restoreItemPanelList();
  }

  ngAfterViewInit(): void {
    const droppable: Droppable = new Droppable(this.element.nativeElement, {
      drop: (e: DropEventArgs) => {
        const elementId = e.droppedElement.id;
        this.dropService.setItemPanelElements(Number(elementId));
        e.droppedElement.remove();
      }
    });
  }

  onClose(id: Number): void {
    this.dropService.deleteItemPanelElements(id);
  }

  async navigate(): Promise<void> {
    let id : Number;
    let inputArray = [];
    this.dropService.getItemPanelsList().forEach((elem) => {
      inputArray.push(elem.val);
    })
    const payload = {"inputs" : inputArray};
      this.subscription$ = this.inputService.createDebtModel(payload).subscribe((resp)=>{
        id = resp.response?.id;
        this.route.navigate(['/input/'+ id +'/generalDetails']);
     });
  }

  ngOnDestroy(): void {
    this.subscription$.unsubscribe();
  }
}
