import { DebtModelService } from './../../_shared/services/debt-model.service';
import { IApiResponse } from './../../../../_shared/models/response';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import * as inputDetails from '../../_shared/data/input-details.json';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { BehaviorSubject, Subject } from 'rxjs';
import { DebtModel,InputItem } from "../../_shared/models";
import { takeUntil } from "rxjs/operators";

@Component({
  selector: 'input-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
})
export class CarouselComponent implements OnInit, OnDestroy {
  public inputDetails:InputItem[];
  public selectedkey = 'generalDetails';
  private debtModelId;
  private selectedItems = [];
  private onDestroy$ = new Subject();

  public customOptions: OwlOptions = {
    loop: false,
    items: 5,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    margin: 10,
    navSpeed: 700,
    navText: ['<em class="fa fa-chevron-left"></em>', '<em class="fa fa-chevron-right"></em>'],
    nav: true,
  };

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private debtModelService: DebtModelService) {}

  ngOnInit(): void {
    this.getRouteParams();
  }

  private getSelectedInputItems(): void {
    this.debtModelService.getDebtModelListener()
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((data:IApiResponse<DebtModel>) => {
      this.selectedItems = data.response.inputs
      this.inputDetails = inputDetails.default.input_item.filter( i => this.selectedItems.includes( i.type ) );
    });
  }

  private getRouteParams():void{
    this.activatedRoute.params
    .pipe(takeUntil(this.onDestroy$))
    .subscribe((params) => {
      this.debtModelId = parseInt(params.id);
      this.selectedkey = params.key;
    });
    this.getSelectedInputItems();
  }

  routeTo(input: InputItem): void {
    this.router.navigate(['input', this.debtModelId, input.key]);
  }

  ngOnDestroy():void{
    this.onDestroy$.next();
    this.onDestroy$.complete();
  }
}
