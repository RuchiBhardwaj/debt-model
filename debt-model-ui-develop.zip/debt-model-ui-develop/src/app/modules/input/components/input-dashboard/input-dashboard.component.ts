import { Component } from '@angular/core';

@Component({
  selector: 'input-dashboard',
  templateUrl: './input-dashboard.component.html',
  styleUrls: ['./input-dashboard.component.scss'],
})
export class InputDashboardComponent {
  constructor() {}
}
