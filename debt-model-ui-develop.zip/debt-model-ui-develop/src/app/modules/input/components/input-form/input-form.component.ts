import { Component } from '@angular/core';

@Component({
  selector: 'input-input-form',
  templateUrl: './input-form.component.html',
  styleUrls: ['./input-form.component.scss'],
})
export class InputFormComponent {
  constructor() {}
}
