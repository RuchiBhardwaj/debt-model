import { ButtonModule } from '@syncfusion/ej2-angular-buttons';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  DetailsFormComponent,
  ItemsPanelComponent,
  InputLandingComponent,
  InputFormComponent,
  InputSidebarComponent,
  InputDetailsCardComponent,
  CarouselComponent,
  CarouselItemCardComponent,
  InputDashboardComponent,
  InputDashboardPanelComponent,
} from './components';
import { InputRoutingModule } from './input-routing.module';
import { TextBoxModule } from '@syncfusion/ej2-angular-inputs';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { PrepaymentDetailsFormComponent } from './components/prepayment-details-form/prepayment-details-form.component';
import { UploaderModule } from '@syncfusion/ej2-angular-inputs';
import { GeneralDetailsFormComponent } from './components/general-details-form/general-details-form.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { InputInterestFormComponent } from './components/input-interest-form/input-interest-form.component';

@NgModule({
  declarations: [
    DetailsFormComponent,
    ItemsPanelComponent,
    InputLandingComponent,
    InputFormComponent,
    InputSidebarComponent,
    InputDashboardComponent,
    InputDetailsCardComponent,
    CarouselComponent,
    CarouselItemCardComponent,
    GeneralDetailsFormComponent,
    PrepaymentDetailsFormComponent,
    InputDashboardPanelComponent,
    InputInterestFormComponent,
  ],
  imports: [
    CommonModule,
    InputRoutingModule,
    TextBoxModule,
    ButtonModule,
    FormsModule,
    ButtonModule,
    InputRoutingModule,
    UploaderModule,
    ReactiveFormsModule,
    CarouselModule,
  ],
})
export class InputModule {}
