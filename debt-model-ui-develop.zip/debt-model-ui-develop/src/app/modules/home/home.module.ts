import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { HomeComponent } from './components';
import { HomeRoutingModule } from './home-routing.module';

import { GridModule, PageService } from '@syncfusion/ej2-angular-grids';
import { HomeService } from './services';
import { SharedModule } from 'src/app/_shared/shared.module';

@NgModule({
  declarations: [HomeComponent],
  imports: [CommonModule, HomeRoutingModule, GridModule, SharedModule],
  providers: [PageService, HomeService, DecimalPipe],
})
export class HomeModule {}
