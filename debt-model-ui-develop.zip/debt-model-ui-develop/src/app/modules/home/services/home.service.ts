import { Injectable } from '@angular/core';
import { DentModelClass, IDebtModelGrid, IDebtModelResponse, IPaginationParams } from '../model/debtModel.model';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { homeConstants, APIConstants } from 'src/app/_shared/constants';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { DmDecimalPipe, DmPercentagePipe } from 'src/app/_shared/pipe';
@Injectable({
  providedIn: 'root',
})
export class HomeService {

  url = environment.baseURL + APIConstants.debtModelValuation;

  constructor(private http: HttpClient, private dmDecimalPipe: DmDecimalPipe) { }

  getAllDebtModel(params?: IPaginationParams): Observable<IDebtModelResponse> {
    let httpParams = new HttpParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value) {
          httpParams = httpParams.append(key, value);
        }
      });
    }
    return this.http.get(this.url, { params: httpParams }).pipe(map(
      (resp: Response) => {
        return this.gridDataTransform(resp['response']);
      }));
  }

  gridDataTransform = (values: IDebtModelResponse) => {
    values['gridData'] = [];
    values['items'].map((data) => {
      const category: IDebtModelGrid = {};
      for (const prop in new DentModelClass()) {
        switch (prop) {
          case 'status':
            category['status'] = (data['analysisDate'] && data['generalDetails']) ? homeConstants.completed : homeConstants.inProgress;
            break;
          case 'fundName':
          case 'originationDate':
          case 'valuationDate':
          case 'maturityDate':
          case 'currentValue':
            if (data.generalDetails) {
              if (prop === 'currentValue') {
                data.generalDetails['currentValue'] = this.dmDecimalPipe.transform(data.generalDetails['principalAmount'] * data.generalDetails['principalOutstanding'] / 100);
              }
            }
            category[prop] = data.generalDetails ? data.generalDetails[prop] || '-' : '-';
            break;
          case 'discountRate':
          case 'percentagePar':
          case 'presentValueSum':
            if (data.cashflow && data.cashflow[prop] !== 0) {
              data.cashflow[prop] = this.dmDecimalPipe.transform(data.cashflow[prop]);
              if (prop === 'percentagePar' || prop === 'discountRate') {
                const percentPipe = new DmPercentagePipe();
                data.cashflow[prop] = percentPipe.transform(data.cashflow[prop]);
              }
            }
            category[prop] = data.cashflow ? data.cashflow[prop] || '-' : '-';
            break;
          default:
            category[prop] = data[prop] || '-';
            break;
        }
      }
      values['gridData'].push(category);
    })
    return values;
  };
}
