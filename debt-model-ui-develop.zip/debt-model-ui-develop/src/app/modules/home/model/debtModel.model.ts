export interface IDebtModel{
  id: number;
  inputs: any;
  analysisDate: string;
  generalDetails: object;
  cashflow: object
}

export interface IDebtModelResponse {
  gridData?: IDebtModelGrid[];
  items: IDebtModel[];
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}

export interface IPaginationParams {
  pageNumber?: number,
  pageSize?: number,
  sortField?: string,
  sortOrder?: string // "ASC" | "DESC"
};

export interface IDebtModelGrid {
  id?: number;
  fundName?: string;
  originationDate?: string;
  valuationDate?: string;
  maturityDate?: string;
  discountRate?: string;
  currentValue?: string;
  presentValueSum?: string;
  percentagePar?: string;
  status?: string;
  statusClass?: object;
}

export class DentModelClass implements IDebtModelGrid {
  id: number = null;
  fundName?: string = null;
  originationDate?: string = null;
  valuationDate?: string = null;
  maturityDate?: string = null;
  discountRate?: string = null;
  currentValue?: string = null;
  presentValueSum?: string = null;
  percentagePar?: string = null;
  status?: string = null;
  statusClass?: object = null;
}
