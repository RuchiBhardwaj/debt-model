import { Component, OnInit, OnDestroy } from '@angular/core';
import { HomeService } from '../../services';
import { Router } from '@angular/router';
import { homeConstants } from 'src/app/_shared/constants';
import { SharedService } from 'src/app/_shared/services';
import { IDebtModelResponse, IPaginationParams, IDebtModelGrid } from '../../model/debtModel.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'home-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {
  public pageSettings = { pageSize: null, pageNumber: null, totalSize: null };
  public customAttributes: object;
  public constants = homeConstants;
  public debtModels: IDebtModelGrid[];
  private subscription$ = new Subscription();
  defaultId: number;

  constructor(private homeService: HomeService, private route: Router, private sharedService: SharedService) { }

  openFund(event): void {
    if (event.target.getAttribute('aria-colindex') === '8') {

      // Navigate to Input page with id if selected DebtModel status is in progress
      if (event.target.innerText === this.constants.inProgress) {
        this.route.navigate(['/input', event.data.id, 'generalDetails']);
      }

      // Navigate to cashflow page with id if selected DebtModel status is completed
      if (event.target.innerText === this.constants.completed) {
        this.route.navigate(['/cashflow', event.data.id]);
      }
    }
  }

  customiseCell(event): void {

    // On grid load and if column is status
    if (event.column.field === 'status') {

      // Adding custom styles
      event.cell.classList.add(event.data.status === this.constants.completed ? 'completed' : 'in-progress');

      // if the default DebtModel ID if not available, find id for completed DebtModel to set default DebtModel ID for cashflow page.
      if(event.data.status === this.constants.completed && !this.defaultId){
        this.sharedService.setDebtModelID(event.data.id);
      }
    }
  }

  getDebtModel(number: number = 0, size: number = 10, order: string = 'DESC'): void {
    // If the page is not active
    if (this.pageSettings.pageNumber !== number) {

      // set query params
      const paginator: IPaginationParams = {
        pageNumber: number,
        pageSize: size,
        sortOrder: order
      }

      // Get all DebtModel list with above query params
      this.subscription$.add(this.homeService.getAllDebtModel(paginator).subscribe((resp?: IDebtModelResponse) => {
        if (resp) {
          this.pageSettings.pageSize = resp.pageSize;
          this.pageSettings.pageNumber = resp.pageNumber;
          this.pageSettings.totalSize = resp.totalPages;
          this.debtModels = resp['gridData'];
        }
      }));
    }
  }

  // Grid pagination events
  pagerNavigation(direction): void {
    switch (direction) {
      case 'first':
        this.getDebtModel(0);
        break;
      case 'previous':
        if (this.pageSettings.pageNumber >= 1) {
          this.getDebtModel(this.pageSettings.pageNumber - 1);
        }
        break;
      case 'next':
        if (this.pageSettings.pageNumber <= this.pageSettings.totalSize) {
          this.getDebtModel(this.pageSettings.pageNumber + 1);
        }
        break;
      case 'last':
        this.getDebtModel(this.pageSettings.totalSize);
        break;
    }
  }

  ngOnInit(): void {
    // Get default DebtModel id
    this.subscription$.add(this.sharedService.debtModelId.subscribe((id: number) => {
      this.defaultId = id;
    }));
    this.getDebtModel();
    this.customAttributes = { class: 'custom-grid' };
  }

  ngOnDestroy(): void {
    this.subscription$.unsubscribe();
  }

}
