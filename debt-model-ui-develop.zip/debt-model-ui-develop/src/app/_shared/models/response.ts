export interface IApiResponse<T> {
  errorCode: string,
  message:	string,
  response: T,
  success:	boolean,
}
