import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { HeaderComponent, NotFoundComponent } from './components';
import { SharedRoutingModule } from './shared-routing.module';
import { SharedService } from './services';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoaderComponent } from './components/loader/loader.component';
import { DmPercentagePipe, DmDecimalPipe } from './pipe';
import { httpInterceptorProviders } from "./interceptors";

@NgModule({
  declarations: [HeaderComponent, NotFoundComponent, LoaderComponent, DmPercentagePipe, DmDecimalPipe],
  imports: [CommonModule, FormsModule, ReactiveFormsModule, SharedRoutingModule],
  exports: [HeaderComponent, LoaderComponent, DmPercentagePipe, DmDecimalPipe],

  providers: [DecimalPipe, DmDecimalPipe],
})
export class SharedModule {
  static forRoot(): ModuleWithProviders<{}> {
    return {
      ngModule: SharedModule,
      providers: [
        SharedService,
        httpInterceptorProviders
      ]
    }
  }
}
