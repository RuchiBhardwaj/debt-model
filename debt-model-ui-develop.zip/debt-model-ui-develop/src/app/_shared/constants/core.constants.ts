export const coreConstants = {
  home: 'Home',
  input: 'Input',
  discRate: 'Discount Rate',
  cashflow: 'Cashflow',
  summary: 'Summary',
  syntheticCreditRating: 'Synthetic  Credit Rating',
  cashflowAnalysis: 'Cashflow Analysis',
};
