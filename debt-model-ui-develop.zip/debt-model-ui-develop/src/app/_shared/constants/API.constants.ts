export const APIConstants = {
    debtModelValuation: 'valuation/debt-model'
};
