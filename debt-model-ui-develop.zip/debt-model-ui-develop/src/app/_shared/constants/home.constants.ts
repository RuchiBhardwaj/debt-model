export const homeConstants = {
  fundName: 'Fund Name',
  originationDate: 'Origination Date',
  valuationDate: 'Valuation Date',
  maturityDate: 'Maturity Date',
  discountRate: 'Discount Rate',
  currentValue: 'Current Value',
  percentagePar: '% of Par',
  presentValueSum: 'Sum of PV',
  status: 'Status',
  inProgress: 'In Progress',
  completed: 'Completed',
  createValuation: 'Create New Valuation',
};
