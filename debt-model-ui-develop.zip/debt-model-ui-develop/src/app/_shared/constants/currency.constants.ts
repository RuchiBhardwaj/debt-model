export const currencyConstants = ['USD', 'EUR', 'JPY', 'GBP', 'INR'];
