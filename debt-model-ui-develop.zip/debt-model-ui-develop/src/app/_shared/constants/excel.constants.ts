export const excelConstants = {
 excelType : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8',
 excelExtension : '.xlsx'
}
