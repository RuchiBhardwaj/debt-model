import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver-es';
import * as XLSX from 'xlsx';
import { excelConstants } from "../../constants";

@Injectable({
  providedIn: 'root'
})
export class ExcelService {

  constructor() { }

  public exportExcelFile(excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet([
      { A: "Interim Variable Payments", B: ""}
    ], {header: ["A", "B"], skipHeader: true});
    XLSX.utils.sheet_add_json(worksheet, [
      { A: "Date", B: "Amount" }, { A: "2019-03-10", B: 25 }, { A: "2019-07-11", B: 25 }
    ], {skipHeader: true, origin: "A2"});
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
     const data: Blob = new Blob([buffer], {type: excelConstants.excelType});
     FileSaver.saveAs(data, fileName + excelConstants.excelExtension);
  }
}
