import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  isLoading = new BehaviorSubject<boolean>(null);
  constructor() {}

  show(): void {
    this.isLoading.next(true);
    return;
  }
  hide(): void {
    this.isLoading.next(false);
    return;
  }
}
