import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HelperService {

  constructor() { }

  removeItem(arr:Array<string>, item:string): Array<String> {
    return arr.filter(f => f !== item)
  }

  convertCamelCaseToSnakeCase(key:string): string {
    var result = key.replace( /([A-Z])/g, " $1" );
    return result.split(' ').join('_').toUpperCase();
 }

  convertSnakeCaseToCamelCase(key:string): string {
    return key.toLowerCase().replace(/([-_][a-z])/g, group =>
    group
      .toUpperCase()
      .replace('-', '')
      .replace('_', '')
    );
  }
}
