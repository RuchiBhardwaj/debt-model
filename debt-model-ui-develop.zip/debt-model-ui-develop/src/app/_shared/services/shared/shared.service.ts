import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  
  public debtModelId = new BehaviorSubject<number>(null);

  constructor() {}

  // Set default DebtModel ID
  setDebtModelID(value): void {
    this.debtModelId.next(value);
  }

  // Get default DebtModel ID
  getDebtModelId(): number {
    return this.debtModelId['_value'];
  }
}
