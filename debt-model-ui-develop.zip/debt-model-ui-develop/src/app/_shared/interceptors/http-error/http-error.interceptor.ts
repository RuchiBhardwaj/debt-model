import { DialogUtility } from '@syncfusion/ej2-popups';
import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  DialogObj;
  constructor() {}

  // TODO: Replace any with type?
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      retry(1),
      catchError((error: HttpErrorResponse) => {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
          // client-side error
          errorMessage = `Error: ${error.error.message}`;
        } else {
          // server-side error
          errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        this.alertError(errorMessage);
        return throwError(errorMessage);
      })
    );
  }

  alertError(errorMessage): void {
    this.DialogObj = DialogUtility.alert({
      title: `<div>An Error occurred while accessing the server Please try again.</div>`,
      content: errorMessage,
      okButton: {
        text: 'OK',
        click: this.dismiss.bind(this),
        cssClass: 'btn-info',
      },
      showCloseIcon: false,
      closeOnEscape: false,
    });
  }

  dismiss(): void {
    this.DialogObj.hide();
  }
}
