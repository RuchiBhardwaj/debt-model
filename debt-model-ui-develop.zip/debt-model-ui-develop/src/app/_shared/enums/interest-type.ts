export enum InterestType {
  PAID = "PAID",
  ACCURED = "ACCURED",
}
