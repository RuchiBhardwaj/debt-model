import { DmPercentagePipe } from './dm-percentage.pipe';

describe('DmPercentagePipe', () => {
  it('create an instance', () => {
    const pipe = new DmPercentagePipe();
    expect(pipe).toBeTruthy();
  });
});
