import { TestBed } from '@angular/core/testing';
import { DmDecimalPipe } from './dm-decimal.pipe';
import { DecimalPipe } from '@angular/common';

describe('DmDecimalPipe', () => {
  let pipe = DmDecimalPipe;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DmDecimalPipe],
      providers: [DecimalPipe]
    }).compileComponents();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });
});
