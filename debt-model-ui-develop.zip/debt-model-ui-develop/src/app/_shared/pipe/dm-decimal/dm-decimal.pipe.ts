import { Pipe, PipeTransform } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'dmDecimal'
})
export class DmDecimalPipe implements PipeTransform {

  constructor(private decimalPipe: DecimalPipe) {}

  transform(value: number): any {
    return this.decimalPipe.transform(value, '1.3-3');
  }

}
