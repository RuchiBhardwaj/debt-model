import { Component, EventEmitter, Input, Output} from '@angular/core';
import { Subscription } from 'rxjs';
@Component({
  selector: 'shared-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  @Input() menuList: Array<any>;
  @Output() selectedItems: EventEmitter<any> = new EventEmitter();
  @Input() defaultSelection;
  menuItems = [];
  subscription$ = new Subscription();

  constructor() { }

  onSelect? = (args?): void => {
    // Emits selected item if it is not in disabled state
    if(!args.disabled) {
      this.defaultSelection = args.text;
      const item = {
        menuTitle: args.text,
        pageTitle: args.pageTitle,
        url: args.path,
      };
      this.selectedItems.emit(item);
    }
  };

  ngOnInit(): void { }

}
