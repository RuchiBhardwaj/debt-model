import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from '../_shared/components';
import { MainContainerComponent } from './components';

const parentRoutes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    component: MainContainerComponent,
    children: [
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full',
      },
      {
        path: 'home',
        loadChildren: () => import('../modules/home/home.module').then((m) => m.HomeModule),
      },
      {
        path: 'cashflow',
        loadChildren: () => import('../modules/cashflow/cashflow.module').then((m) => m.CashflowModule),
      },
      {
        path: 'input',
        loadChildren: () => import('../modules/input/input.module').then((m) => m.InputModule),
      },
      {
        path: 'pageNotFound',
        component: NotFoundComponent,
      },
      {
        path: '**',
        redirectTo: 'pageNotFound',
        pathMatch: 'full',
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(parentRoutes)],
  exports: [RouterModule],
})
export class CoreRoutingModule {}
