import { coreConstants } from 'src/app/_shared/constants';

//Handling Menu option default disabled value here
export const menuItems = [
  { text: coreConstants.home, path: 'home', pageTitle: coreConstants.home, disabled: false },
  { text: coreConstants.input, path: 'input', pageTitle: coreConstants.input, disabled: false },
  { text: coreConstants.discRate, path: 'discRate', pageTitle: coreConstants.discRate, disabled: true },
  { text: coreConstants.cashflow, path: 'cashflow', pageTitle: coreConstants.cashflowAnalysis, disabled: true },
  { text: coreConstants.summary, path: 'summary', pageTitle: coreConstants.summary, disabled: true },
];

export const homeMenu = [
  { text: coreConstants.home, path: 'home', disabled: false }
];
