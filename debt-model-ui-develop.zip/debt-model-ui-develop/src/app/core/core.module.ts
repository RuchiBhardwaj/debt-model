import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CoreRoutingModule } from './core-routing.module';
import { AppComponent, MainContainerComponent } from './components';
import { SharedModule } from '../_shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [AppComponent, MainContainerComponent],
  imports: [BrowserModule, CoreRoutingModule, BrowserAnimationsModule, SharedModule.forRoot(), HttpClientModule],
  bootstrap: [AppComponent],
  providers: [],
})
export class CoreModule {}
