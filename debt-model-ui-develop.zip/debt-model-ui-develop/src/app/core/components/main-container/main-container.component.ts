import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { menuItems, homeMenu } from '../../mocks';
import { coreConstants } from 'src/app/_shared/constants';

@Component({
  selector: 'core-main-container',
  templateUrl: './main-container.component.html',
  styleUrls: ['./main-container.component.scss'],
})
export class MainContainerComponent implements OnInit, OnDestroy {
  menuForHome = homeMenu;
  menuForAll = menuItems;
  menuItems: Array<object>;
  selectedItem: any;
  subscription$ = new Subscription();

  constructor(private router: Router) { }
  
  // Menu Navigations
  onItemSelection(item?: any): void {
    // Page navigation on menu item selection
    this.router.navigate([`${item.url}`]);
  }

  ngOnInit(): void {
    // Update menu selection on page load
    this.menuItems = this.menuForHome;
    this.updateMenu(window.location.pathname.split('/')[1]);

    // Update menu selection on page navigation
    this.subscription$.add(this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        this.updateMenu(event.url.split('/')[1]);
      }
    }));
  }

  updateMenu(activePath) {
    if (activePath == 'home') {
      this.menuItems = this.menuForHome;
    } else {
      this.menuItems = this.menuForAll;
    }
    this.menuItems.map(element => {
      (element['text'] == coreConstants.cashflow)? element['disabled'] = ((activePath === element['path'])?  false : true): null;
    })
    this.selectedItem = this.menuItems.find(element => element['path'] === activePath);
  }

  ngOnDestroy(): void {
    this.subscription$.unsubscribe();
  }

}
