export * from './app/app.component';
export * from './main-container/main-container.component';
